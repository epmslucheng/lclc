/**
 *  配置默认文件路径
 * @authors JiHonghai  (jihonghai@chinasofti.com)
 * @date    2016-12-18 10:27:19
 * @version 0.1
 */

/**
 * 存放所有安装压缩包的根目录，以/结束。默认为/doc目录。eg: Linux: /home/ami/, Windows: E:\\coding\\AMI-PLATFORM\\。
 */
exports.rootPath = '';

/**
 * 本地存放安装包的目录，目录名中不得含有中文
 */
exports.ZIP_DIR = '/doc/deploy';

/**
 * 服务器上存放压缩包的目录
 */
exports.REMOTE_ZIP_DIR = '/deploy';

/**
 * shell脚本压缩包名称（包含扩展名）
 */
exports.SHELL_ZIP = 'shell.zip';

/**
 * war压缩包名称（包含扩展名）
 */
exports.WAR_ZIP = 'war.zip';

/**
 * 中间件压缩包名称（包含扩展名）
 */
exports.MIDDLEWARE_ZIP = 'middleware.zip';

/**
 * 
 */
exports.DB_SCRIPT_ZIP='dbscript.zip';


/**
 * 升级包名
 */
exports.UPGRADE_ZIP='upgrade.zip';
/**
 * 服务器中存放shell脚本的路径
 */
exports.SHELL_DIR = '/deploy';

/**
 * 安装JDK的脚本名称
 */
exports.INSTALL_JDK_SHELL = 'jdkInstall.sh';

/**
 * Zookeeper的脚本名称
 */
exports.ZK_SHELL_PATH='/usr/local/deploy/bin/zk';
exports.ZK_SHELL_NAME='zk.sh';

/**
 * redis的脚本名称
 */
exports.REDIS_SHELL_PATH='/usr/local/deploy/bin/redis';
exports.REDIS_SHELL_NAME='redis';

/**
 * nginx的脚本名称
 */
exports.NGINX_SHELL_PATH='/usr/local/deploy/bin/nginx';
exports.NGINX_SHELL_NAME='nginx.sh';

/**
 * 应用的脚本名称
 */
exports.APP_SHELL_PATH='/usr/local/deploy/bin/module';
exports.APP_SHELL_NAME='moduleNew.sh';
exports.APPALL_SHELL_NAME='moduleAll.sh';

/**
 * 方案的脚本名称
 */
exports.PLAN_SHELL_PATH='/usr/local/deploy';
exports.INSTALL_SHELL_NAME='installAll.sh';
exports.UNINSTALL_SHELL_NAME='unInstall-all.sh';
exports.RESTART_SHELL_NAME='restart-all.sh';
exports.START_SHELL_NAME='start-all.sh';
exports.STOP_SHELL_NAME='stop-all.sh';

exports.INIT_DB_SHELL='initDB.sh';

exports.REMOTE_LOG_DIR='/usr/local/deploy/log/';
exports.LOCAL_LOG_DIR= __dirname + '/../log/';

/**
 * 升级脚本
 */
exports.UPGRADE_LOCAL_PATH='/temp/';
exports.UPGRADE_SHELL_PATH='/usr/local/deploy/bin/upgrade';
exports.UPGRADE_SHELL_NAME='upgrade.sh';


