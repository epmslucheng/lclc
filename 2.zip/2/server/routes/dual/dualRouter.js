const express = require('express');
const router = express.Router();
const extend = require('extend');
const path = require('path');
const $ = require('jquery-deferred');

const neUtils = require('../../lib/ne-utils');
const logger = require('../../lib/logger');
const response = require('../../lib/response-utils');
const serverUtils = require('../../lib/server/server-utils');

/* Go to list */
router.get('/', function (req, res, next) {
    res.render('dual/dual-list', {
        title: 'Dual List',
        layout: 'layout/default'
    });
});

router.post('/list', function (req, res, next) {
    queryDual(req, res);
});

router.post('/new', function (req, res, next) {
    insertDual(req, res);
});

router.post('/delete/:id', function (req, res, next) {
    findOneDual(req, res, next).done(function(data){
        neUtils.dual.remove({
            _id: req.params.id
        }, {}, function (err, numRemoved) {
            if (err) {
                logger.error('delete dual failed: %s', err + '');
                response.renderError(res);
            } else {
                if (numRemoved > 0) {
                    var a = [data.node1,data.node2];
                    serverUtils.updateServerUsed(a,0);

                    response.renderSuccess(res);
                } else {
                    response.renderError(res);
                }
            }
        });
    })
});

router.get('/detail/:id', function (req, res, next) {
    neUtils.dual.findOne({
        _id: req.params.id
    }, function (err, dual) {
        if (err) {

        } else {
            res.render('dual/dual-detail', {
                title: '',
                layout: 'layout/singlefile',
                dual: dual
            });
        }
    });
    return res;
});

function findOneDual(req, res, next){
    var deferred = $.Deferred();
    neUtils.dual.findOne({
        _id: req.params.id
    },function (err, doc) {
        if (err) {
            logger.error('查询app记录数失败:%s', err + '');
            deferred.reject(err);
        } else {
            deferred.resolve(doc);
        }
    })
    return deferred;
}

function queryDual(req, res) {
    var params = req.body;
    var page = params.offset;
    var pageSize = params.limit;

    neUtils.dual.queryList({}, page, pageSize).done((data) => {
        res.json(data);
    }).fail((error) => {
        logger.error(error);
    });
}

function insertDual(req, res) {
    var params = req.body;

    neUtils.dual.insert(params, (err) => {
        if (err) {
            logger.error('Create dual failed: %s', err + '');
            response.renderError(res, 'Create dual failed');
        } else {
            var a = [params.node1,params.node2];
            serverUtils.updateServerUsed(a,1);

            response.renderSuccess(res, 'Create dual success');
        }
    });
}

module.exports = router;