const express = require('express');
const router = express.Router();
const extend = require('extend');
const path = require('path');
const $ = require('jquery-deferred');
const fs = require('fs');

const neUtils = require('../../lib/ne-utils');
const logger = require('../../lib/logger');
const response = require('../../lib/response-utils');
const planUtils = require('../../lib/plan/plan-utils');
const fileConfig = require('../../../resources/config/fileConfig');
const shell = require('../../lib/shell');
const commonConstant = require('../../lib/constant/common');
const serverUtils = require('../../lib/server/server-utils');
const upgradeUtils = require('../../lib/upgrade/upgrade-utils');

/* Go to serverList */
router.get('/', function (req, res, next) {

    const plan = {};
    const deferreds = planUtils.initBaseData(plan);

    $.when.apply(null, deferreds).done(() => {
        res.render('plan/plan-list', {
            title: 'Plan List',
            layout: 'layout/default',
            plan: plan
        });
    }).fail((err) => {
        logger.error('query node failed: %s', err);
        response.renderError(res, 'Create dual failed');
    });
});

router.post('/list', function (req, res, next) {
    planUtils.queryPlanList(req, res);
});

router.post('/new', function (req, res, next) {
    planUtils.insertPlan(req, res);
});

router.get('/detail/:id', function (req, res, next) {
    neUtils.plan.findOne({
        _id: req.params.id
    }, function (err, plan) {
        if (err) {

        } else {
            const deferreds = planUtils.initSelectedBaseData(plan);

            $.when.apply(null, deferreds).done(() => {
                if(plan.groupPO==null){
                    plan.groupPO = {}
                }
                if(plan.dualPO==null){
                    plan.dualPO = {}
                }
                if(plan.serverPO==null){
                    plan.serverPO = {}
                }
                if(plan.dbPO==null){
                    plan.dbPO = {}
                }
                res.render('plan/plan-detail', {
                    title: 'Plan Detail',
                    layout: 'layout/default',
                    plan: plan
                });
            }).fail((err) => {
                logger.error('query plan detail failed: %s', err);
                response.renderError(res, 'query plan detail failed');
            });
        }
    });
});

router.post('/edit', function (req, res, next) {
    var params = req.body;
    neUtils.plan.update({
        _id: params._id
    }, {
        $set: {
            Name: params.Name,
            Version: params.Version,
            Desc: params.Desc
        }
    }, (err) => {
        if (err) {
            logger.error('update error:' + err);
            response.renderError(res, 'update error');
        } else {
            response.renderSuccess(res, 'update success');
        }
    });
});

router.post('/delete/:id', function (req, res, next) {
    planUtils.findOnePlan(req, res, next).done(function(data){
        neUtils.plan.remove({
            _id: req.params.id
        }, {}, function (err, numRemoved) {
            if (err) {
                logger.error('delete plan failed: %s', err + '');
                response.renderError(res);
            } else {
                if (numRemoved > 0) {
                    planUtils.usedNotice(data,0);
                    response.renderSuccess(res);
                } else {
                    response.renderError(res);
                }
            }
        });
    })
});

router.post('/updateGroupDetail', function (req, res) {
    planUtils.updateGroupDetail(req, res);
});

router.get('/historyList', function (req, res) {
    res.render('plan/plan-history', extend({
        title: 'Plan History',
        layout: 'layout/default'
    }, req.query));
});

router.post('/historyList', function (req, res) {
    planUtils.historyList(req, res);
});

router.post('/readFile', function (req, res) {
    var logName = req.body.logName;
    fs.readFile(fileConfig.LOCAL_LOG_DIR + logName, {flag: 'r+', encoding: 'utf8'}, function (err, data) {
        if(err) {
            logger.error(err);
        } else {
            res.send(data);
            res.end();
        }
    });
});

router.post('/addHistory', function (req, res) {
    planUtils.addHistory(req, res);
});

router.get('/upgrade/:id', function (req, res) {
    neUtils.plan.findOne({
        _id: req.params.id
    }, function (err, plan) {
        if (err) {

        } else {
            const deferreds = planUtils.initSelectedBaseData(plan);

            $.when.apply(null, deferreds).done(() => {
                plan.Components = ["Nginx","Zookeeper","Redis","Portal","Sale","Mdm","Read","Task","Support","Interface","Monitor","Sts","Eem_Arabic"];
                if(plan.groupPO==null){
                    plan.groupPO = {}
                }
                if(plan.dualPO==null){
                    plan.dualPO = {}
                }
                if(plan.serverPO==null){
                    plan.serverPO = {}
                }
                if(plan.dbPO==null){
                    plan.dbPO = {}
                }
                res.render('plan/plan-upgrade', {
                    title: 'Plan Upgrade',
                    layout: 'layout/default',
                    plan: plan
                });
            }).fail((err) => {
                logger.error('query plan detail failed: %s', err);
                response.renderError(res, 'query plan detail failed');
            });
        }
    });
});

router.post('/getFilesAndDirs', function (req, res) {
    var params = req.body;   
    var nIP = params.ip;
    serverUtils.findServerByIP(nIP).done((result) => {
        if (result && result.length) {
            const config = {
                server: {
                    host: result[0].IP,
                    username: 'root',
                    password: result[0].rootPwd
                },
                user:result[0].user
            };

            shell.getFilesAndDirs(config.server,params.quickCondition,params.path, function (err, data,conn) {
                if (err) {
                    logger.error('get files and dirs from remote failed: %s', err);
                    response.renderError(res, 'get files and dirs from remote failed');
                } else {
                    res.json(data);
                }
                conn.end;
            });
        } else {
            logger.error('get files and dirs from remote failed');
            response.renderError(res, 'get files and dirs from remote failed');
        }
    }).fail(() => {
        logger.error('get files and dirs from remote failed: %s');
        response.renderError(res, 'get files and dirs from remote failed');
    });


    
});

router.get('/viewConfigDetail',function (req, res) {
    const params = req.body;
    res.render('plan/view-config', extend({
        title: params.title,
        layout: 'layout/singlefile'
    }, req.query));
});

router.post('/readRemoteFile', function(req, res) {
    var params = req.body;   

    var nIP = params.ip;
    serverUtils.findServerByIP(nIP).done((result) => {
        if (result && result.length) {
            const config = {
                server: {
                    host: result[0].IP,
                    username: 'root',
                    password: result[0].rootPwd
                },
                user:result[0].user
            };

            shell.readFileSudo(config.server,params.remoteFile, function (err, data,conn) {
                if (err) {
                    logger.error('read remote file failed: %s',  err);
                    response.renderError(res, 'read remote file failed');
                } else {
                    var strs = [];
                    response.renderSuccessConfig(res,data);
                }
                conn.end;
            });
        } else {
            logger.error('get files and dirs from remote failed');
            response.renderError(res, 'get files and dirs from remote failed');
        }
    }).fail(() => {
        logger.error('get files and dirs from remote failed: %s');
        response.renderError(res, 'get files and dirs from remote failed');
    });
   
});

router.get('/replaceRemoteAndBackupOld',function (req, res) {
    const params = req.body;
    res.render('plan/upgrade-upload', extend({
        title: params.title,
        layout: 'layout/singlefile'
    }, req.query));
});

router.get('/rollback',function (req, res) {
    const params = req.body;
    res.render('plan/plan-rollback', extend({
        title: params.title,
        layout: 'layout/singlefile'
    }, req.query));
});

router.post('/rollbackOpt', (req, res) => {
    upgradeUtils.remoteRollbackOperate(req, res);
});
module.exports = router;