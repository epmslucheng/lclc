const express = require('express');
const router = express.Router();
const extend = require('extend');
const path = require('path');
const log4js = require('log4js');
const multiparty = require('multiparty');

const neUtils = require('../../lib/ne-utils');
const response = require('../../lib/response-utils');
const shell = require('../../lib/shell');
const logger = require('../../lib/logger');

const fileConfig = require('../../../resources/config/fileConfig');
const db = require('../../lib/db/db-utils');

const fileUploadPath = './temp/';

//跳转数据库列表页
router.get('/toList', (req, res) => {
    res.render('db/list', {
        title: 'Data Base',
        layout: 'layout/default'
    });
});
//查询列表数据
router.post('/list', function (req, res, next) {
    db.query(req, res);
});

//跳转新增页面
router.get('/toAdd', function (req, res, next) {
    res.render('db/add', {
        title: 'New Database',
        layout: 'layout/singlefile'
    });
});
router.post('/add', function (req, res, next) {
    db.add(req, res);
});

router.post('/edit', function (req, res, next) {
    db.update(req, res);
});

router.post('/delete/:ip', function (req, res, next) {
    db.delete(req.params.ip, res);
});

//跳转初始化页面
router.get('/toInit', function (req, res, next) {
    res.render('db/init',  extend({
        title: 'Initialize Database',
        layout: 'layout/singlefile'
    },req.query));
});

router.post('/upload', (req, res) => {
    //生成multiparty对象，并配置上传目标路径
    const form = new multiparty.Form({
        uploadDir: fileUploadPath
    });

    //上传完成后处理
    form.parse(req, (err, fields, files) => {
        if (err) {
            logger.debug('Import file parse error: ' + err);
        } else {
            const inputFile = files.sqlFile[0];
            var uploadedPath = inputFile.path;

            const originalFilename = inputFile.originalFilename;
            uploadedPath = uploadedPath.replace('\\', '\\\\');

            res.writeHead(200, {
                'content-type': 'application/json;charset=utf-8'
            });
            res.end('{"resultCode": "200", "path":"' + uploadedPath.split('\\')[2] + '", "fileName":"' + originalFilename + '"}');
        }
    });
});

/**
 * 初始化数据库。
 * 步骤：
 * 1、将数据库脚本zip上传至数据库服务器
 * 2、解压缩数据库脚本zip
 * 3、将shell脚本上传到数据库服务器
 * 4、通过shell执行sql，进行初始化
 */
router.post('/initDB', function (req, res, next){
    var params = req.body;

    neUtils.db.findOne({'ip':params.ip}, function (err, dbPO) {

        logger.info("init database:id:"+ params.id +" sid:"+ dbPO.ip+"_"+dbPO.sid);
        var config = {
            server: {
                host: dbPO.ip,
                username: 'root',
                password: dbPO.password
            },
            dbConn: dbPO.ip+":"+dbPO.port+"/"+dbPO.sid,
            dbDir: dbPO.dbDir,
            dbSID: dbPO.sid,
            sysPwd: dbPO.sysPwd,
            sidDir: dbPO.sidDir,
            dbID: dbPO._id,
            dbUsername: params.dbUsername,
            dbPassword: params.dbPassword
        };

        db.uploadFiles(config);
    });
    response.renderSuccess(res,"executig...");
});

module.exports = router;