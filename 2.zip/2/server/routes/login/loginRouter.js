const express = require('express');
const router = express.Router();
const extend = require('extend');
const path = require('path');
const $ = require('jquery-deferred');
const uuidV4 = require('uuid/v4');

const response = require('../../lib/response-utils');
const loginUtils = require('../../lib/login/login-utils');

router.get('/', function (req, res,next) {
    loginUtils.renderLogin(req, res);
});

// 用户登录
router.post('/', function(req, res, next) {
    var name = req.body.name;
    var password = req.body.password;

    loginUtils.getUserByName(req, res).done(function (user) {
        if (!user) {
            response.renderError(res, 'User does not exist');
        }else if (password !== user.password) {
            response.renderError(res, 'Password error');
        } else {
            delete user.password;
            req.session.user = user;

            response.renderSuccess(res,'Login success');
        }
    })
});

// 用户登出
router.get('/logout', function(req, res, next) {
    req.session.user = null;
    loginUtils.renderLogin(req, res);
});

module.exports = router;