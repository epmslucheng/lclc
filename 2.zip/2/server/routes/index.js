const express = require('express');
const router = express.Router();

const moduleInstall = require('./application/installModule');
const appInstall = require('./application/applicationRouter');
const serverList = require('./server/serverListRouter');
const dual = require('./dual/dualRouter');
const serverGroupList = require('./server/serverGroupListRouter');
const plan = require('./plan/planRouter');
const db = require('./db/dbRouter');
const login = require('./login/loginRouter');

module.exports = (app) => {
    app.use('/application', appInstall);
    app.use('/server', serverList);
    app.use('/dual', dual);
    app.use('/serverGroup', serverGroupList);
    app.use('/plan', plan);
    app.use('/db', db);
    app.use('/login', login);

    app.use('/', router.get('/', (req, res) => {
        res.redirect('/server');
    }));
};