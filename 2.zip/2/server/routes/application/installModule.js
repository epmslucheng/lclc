const express = require('express');
const router = express.Router();
const extend = require('extend');
const $ = require('jquery-deferred');

const shell = require('../../lib/shell');
const logger = require('../../lib/logger');
const neUtils = require('../../lib/ne-utils');
const commonConstant = require('../../lib/constant/common');
const fileConfig = require('../../../resources/config/fileConfig');

/* Go to portal */
router.get('/installModule', function (req, res, next) {
    res.render('application/installModule', extend({
        title: 'Install Module',
        layout: 'layout/singlefile',
    }, req.query));
});

//安装应用
router.post('/installApp', (req, res) => {
    var params = req.body;
    var module = params.module;
    var user = params.user;
    var optType = params.optType;

    var shellFile = "";
    if("app" == module) {
        shellFile = 'sh '+ fileConfig.RESTART_ALLAPP_SHELL+ ' true ' + user;
        if (optType == "install") {
            shellFile = 'sh '+ fileConfig.INSTALL_ALLAPP_SHELL+ ' true ' + user;
        }
        else if (optType == "unInstall") {
            shellFile = 'sh '+ fileConfig.UNINSTALL_ALLAPP_SHELL+ ' ' + user;
        }
        else if (optType == "restart") {
            shellFile = 'sh '+ fileConfig.RESTART_ALLAPP_SHELL+ ' true ' + user;
        }
    }
    else{
        shellFile = fileConfig.RESTART_APP_SHELL;
        if (optType == "install") {
            shellFile = fileConfig.INSTALL_APP_SHELL;
        }
        else if (optType == "unInstall") {
            shellFile = fileConfig.UNINSTALL_APP_SHELL;
        }
        else if (optType == "restart") {
            shellFile = fileConfig.RESTART_APP_SHELL;
        }

        shellFile = 'sh '+shellFile+ ' ' + module + ' ' + user;
    }

    var config = {
        server: {
            host: params.IP,
            username: user,
            password: 'epms123'
        },
        scriptDir: '/home/' + params.user + fileConfig.SHELL_DIR,
        script: shellFile,
        module: module,
        serverId: params.serverId,
        serverIP: params.IP
    };

    doInstallApp(config, res);
});

//
function doInstallApp(config, res) {
    const user = config.server.username;

    shell.runShell(config.server, (err, stream, conn) => {
        conn.exec('cd ' + config.scriptDir + '; ' + config.script + ';', (err, stream) => {
            var out = [];
            if (err) {
                logger.error(`execute shell ${config.script} error: %s`, '' + err);
                error(res, `execute shell ${config.script} error: ${err}`);
            } else {
                stream.on('close', () => {
                    logger.debug(`deploy ${config.module } success`);
                    broadcastConsoleOut(escape(out.join('')));
                    conn.end();
                    insertOrUpdateApp(config.module, config.serverId, config.serverIP, res);
                }).on('data', (data) => {
                    data = data + '';

                    if (out.length > commonConstant.INSTALL_APP_OUT_MAX_LENGTH) {
                        broadcastConsoleOut(escape(out.join('')));
                        out.length = 0;
                    }

                    out.push('<p>' + data + '</p>');

                    if (serverIsStarted(data)) {
                        stream.close();
                    }
                }).stderr.on('data', (data) => {
                    logger.error('error: ' + data);
                });
            }
        });
    });
}

function broadcastConsoleOut(msg) {
    var socket = require('socket.io-client')(`http://localhost:${process.env.PORT}`);
    socket.on('connect', () => {
        socket.emit('ModulesServer', msg);
    });
}

function error(res, msg) {
    res.writeHead(200, {
        'content-type': 'application/json;charset=utf-8'
    });
    res.end(msg ? '{"resultCode": "500","msg":"' + msg + '"}' : '{"resultCode": "500"}');
}

function success(res, msg) {
    res.writeHead(200, {
        'content-type': 'application/json;charset=utf-8'
    });
    res.end(msg ? '{"resultCode": "200","msg":"' + msg + '"}' : '{"resultCode": "200"}');
}


/**
 * 判断tomcat容器是否已经启动完成
 * @param {String} stdout tomcat容器输出的信息
 */
function serverIsStarted(stdout) {

    return stdout.indexOf('Server startup in') >= 0;
}


/**
 * 新增应用服务
 */
function insertOrUpdateApp(type, serverId, serverIP, res) {
    const deferred = checkAppIsInstalled(type, serverId);
    deferred.done((result) => {
        logger.debug(result);
        if (result && result.length) {
            updateApp({
                type: type,
                serverId: result[0].serverId
            }, res);
        } else {
            insertApp({
                type: type,
                updateTime: new Date(),
                serverId: serverId,
                serverIP: serverIP
            }, res);
        }
    });
}

/**
 * 检查应用是否安装过，如果已安装，返回对应记录的id
 */
function checkAppIsInstalled(type, serverId) {
    var deferred = $.Deferred();
    neUtils.app.find({
        serverId: serverId,
        type: type
    }, (err, result) => {
        if (err) {
            logger.error('查询app记录数失败:%s', err + '');
            deferred.reject(err);
        } else {
            deferred.resolve(result);
        }
    });

    return deferred;
}

function insertApp(params, res) {
    neUtils.app.insert({
        serverId: params.serverId,
        type: params.type,
        updateTime: new Date(),
        serverIP: params.serverIP
    }, (err) => {
        if (err) {
            logger.error(err);
        } else {
            //success(res, `deploy  success`);
        }
    });
}

function updateApp(params, res) {
    neUtils.app.update({
        serverId: params.serverId,
        type: params.type
    }, {
        $set: {
            updateTime: new Date()
        }
    }, (err, result) => {
        if (err) {
            logger.error(err);
        } else {
            //success(res, `deploy  success`);
        }
    });
}

module.exports = router;