const express = require('express');
const router = express.Router();
const extend = require('extend');
const path = require('path');

const logger = require('../../lib/logger');
const shell = require('../../lib/shell');
const applicationUtils = require('../../lib/application/application-utils');
const fileConfig = require('../../../resources/config/fileConfig');
const serverUtils = require('../../lib/server/server-utils');

router.post('/remoteOperate', (req, res) => {
    applicationUtils.remoteOperate(req, res);
});

router.get('/remoteOperate', (req, res) => {
    const params = req.body;
    res.render('application/remoteOperate', extend({
        title: params.title,
        layout: 'layout/singlefile'
    }, req.query));
});

router.get('/viewLog',(req, res) => {
    const params = req.body;
    res.render('plan/log-detail', extend({
        title: params.title,
        layout: 'layout/singlefile'
    }, req.query));
})



router.get('/installjdk', (req, res) => {
    res.render('application/installJDK', extend({
        title: 'JDK',
        layout: 'layout/singlefile'
    }, req.query));
});

router.post('/installjdk', (req, res) => {
    const params = req.body;
    const config = {
        server: {
            host: params.IP,
            username: params.user,
            password: 'epms123'
        },
        serverId: params.serverId
    };
    applicationUtils.installJDK(config, req, res);
});

module.exports = router;