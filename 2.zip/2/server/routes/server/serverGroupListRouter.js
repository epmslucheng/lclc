const express = require('express');
const router = express.Router();
const extend = require('extend');
const path = require('path');
const $ = require('jquery-deferred');
const uuidV4 = require('uuid/v4');

const neUtils = require('../../lib/ne-utils');
const response = require('../../lib/response-utils');
const logger = require('../../lib/logger');
const shell = require('../../lib/shell');
const serverUtils = require('../../lib/server/server-utils');
const fileConfig = require('../../../resources/config/fileConfig');

/* Go to serverList */
router.get('/', function (req, res) {
    res.render('server/serverGroupList', {
        title: 'Server Group List',
        layout: 'layout/default'
    });
});

router.post('/list', function (req, res) {
    serverUtils.queryServerGroup(req, res);

});

router.post('/addServerGroup', function (req, res) {
    serverUtils.addServerGroup(req, res);
});

router.post('/editServerGroup', (req, res) => {
    serverUtils.updateServerGroup(req, res);
});

router.post('/delete/:id', function (req, res, next) {
    serverUtils.deleteServerGroup(req.params.id, res);
});

module.exports = router;