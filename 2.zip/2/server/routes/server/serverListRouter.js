const express = require('express');
const router = express.Router();
const extend = require('extend');
const path = require('path');
const $ = require('jquery-deferred');
const uuidV4 = require('uuid/v4');

const neUtils = require('../../lib/ne-utils');
const response = require('../../lib/response-utils');
const logger = require('../../lib/logger');
const shell = require('../../lib/shell');
const serverUtils = require('../../lib/server/server-utils');
const fileConfig = require('../../../resources/config/fileConfig');
const upgradeUtils = require('../../lib/upgrade/upgrade-utils');
const fileUtils = require('../../lib/file-utils');

/* Go to serverList */
router.get('/', function (req, res) {
    res.render('server/serverList', {
        title: 'Server List',
        layout: 'layout/default'
    });
});

router.post('/list', function (req, res) {
    serverUtils.queryServer(req, res);
});

router.post('/list/all', function (req, res) {
     neUtils.server.find({}, (err, servers) =>{
        if(err){

        }else{
            res.json(servers);
        }
     });
});

router.post('/addServer', function (req, res) {
    serverUtils.addServer(req, res);
});

router.get('/upload', (req, res) => {
    res.render('server/upload', extend({
        title: 'Upload Files',
        layout: 'layout/singlefile'
    }, req.query));
});

router.post('/upload', (req, res) => {
    upgradeUtils.remoteOperate(req, res);
});

router.post('/editServer', (req, res) => {
    serverUtils.updateServer(req, res);
});

router.post('/delete/:ip', function (req, res, next) {
    serverUtils.delete(req.params.ip, res);
});

router.post('/getUploadLocalpath', function (req, res) {
   upgradeUtils.writeFile(req, res, function (data) {
        res.json(data);
    });

});

module.exports = router;