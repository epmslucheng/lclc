const path = require('path');
const express = require('express');
const partials = require('express-partials');
const favicon = require('serve-favicon');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const compress = require('compression');
const errorhandler = require('errorhandler');
const session = require('express-session');
const routes = require('./server/routes/index');
const logger = require('./server/lib/logger');
const loginUtils = require('./server/lib/login/login-utils');

const app = express();

// view engine setup
app.set('views', path.join(__dirname, 'client/views'));
app.set('view engine', 'ejs');

//Use gzip compression
app.use(compress());

// uncomment after placing your favicon in /public
app.use(favicon(__dirname + '/client/public/favicon.ico'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.text([{uploadDir:'./uploads'}]));
app.use(partials());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'client/public')));

app.use(session({
    secret: 'PLATFORM',
    resave: true,
    saveUninitialized: true
}));

app.use(function (req, res, next) {
    loginUtils.checkLogin(req, res, next);
});

//register routes
routes(app);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error(req.url + ' Not Found');
    err.status = 404;
    logger.error(err);
    res.status(err.status || 500);
    res.render('404', {
        message: err.message,
        error: err
    });
});

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(morgan('dev'));

    app.use(function (err, req, res, next) {
        logger.error(err);
        res.status(err.status || 500);
        res.render('500', {
            message: err.message,
            error: err
        });
    });

    app.use(errorhandler());
}

// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
    logger.error(err);
    res.status(err.status || 500);
    res.render('500', {
        message: err.message,
        error: {}
    });
});

module.exports = app;